#include <stdio.h>
#include <stdlib.h>
int hw2_2(void)
{
	int x, y;
	printf("��J���ū�:\n");
	scanf("%d", &x);
	y = 1.8*x + 32;
	printf("�ؤ�ū׬�:%d\n", y);
	system("pause");
	return 0;
}