#include <stdio.h>
#include <stdlib.h>
void hw1_1()
{
	printf("Hello Every One, Welcome to the C World!\n");
}