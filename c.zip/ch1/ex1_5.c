#include<stdio.h>
#include<stdlib.h>
void ex1_5()
{
	int num;
	printf("Please input an integer:");
	scanf("%d", &num);
	printf("num=%d\n", num);
}