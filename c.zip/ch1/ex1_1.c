#include<stdio.h>
#include<stdlib.h>
void ex1_1()
{
	printf("Hello c!\n");
	printf("Hello World!\n");
}