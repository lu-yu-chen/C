#include <stdio.h>
#include <stdlib.h>
void hw1_2()
{
	char x1, x2, x3;
	x1 = 'a';
	x2 = 'b';
	x3 = 'n';
	printf("%c", x2);
	printf("%c", x1);
	printf("%c", x3);
	printf("%c", x1);
	printf("%c", x3);
	printf("%c\n", x1);
}