#include<stdio.h>
#include<stdlib.h>
void ex1_3()
{
	short sum, s = 32767;
	sum = s + 1;
	printf("s+1=%d\n", sum);
	sum = s + 2;
	printf("s+2=%d\n", sum);
}