#include<stdio.h>
#include<stdlib.h>

void hw3_2()
{



}